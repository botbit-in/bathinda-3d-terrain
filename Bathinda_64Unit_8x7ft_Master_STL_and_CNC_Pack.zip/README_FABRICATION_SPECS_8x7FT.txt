=========================================================================
64 ENGR REGT (BATHINDA SECTOR) — 8.0 FT x 7.0 FT MASTER FABRICATION PACK
=========================================================================
1. EXACT PHYSICAL DIMENSIONS (LOCKED 8:7 ASPECT RATIO — DO NOT SQUISH TO 1:1):
   - East-West Width (X) : 8.000 ft = 96.0 in = 2,438.4 mm (152 km sector)
   - North-South Depth (Y): 7.000 ft = 84.0 in = 2,133.6 mm (150 km sector)
   - 1:10 Master STL Size : 243.84 mm (X) x 213.36 mm (Y) x 13.98 mm (Z)
     -> Scale uniformly by 1000% (10x) in Slicer / CNC CAM for 2438.4 x 2133.6 mm!

2. FILES INCLUDED IN THIS ZIP:
   - Bathinda_64Unit_8x7ft_2438x2134mm_Watertight_Master.stl
     100% manifold watertight binary STL (563,000 triangles) with flat Z=0 bottom,
     closed perimeter walls, smoothed SRTM DEM, 14 carved rivers/canals + bunds,
     engraved Radcliffe IB (BP 260-365), 7 highways & 8 barrage/Sarvatra seats.
   - Bathinda_64Unit_8x7ft_2438x2134_16bit_CNC_ZBrush_Heightmap.png
     True 16-bit (0-65535) grayscale displacement alpha at exact 2438 x 2134 px
     (1 pixel = 1.000 mm on the 8x7 ft table!).
   - Bathinda_64Unit_8x7ft_Shopfloor_QC_Blueprint.png
     Full shopfloor plan view with 8x7 ft (1x1 ft = 304.8 mm) tile grid, all 14
     waterways, verified Indian vs Pak towns, 5 Headworks & 3 Sarvatra bridges.

3. LIVE 3D CLIENT REFERENCE VIEWER:
   https://botbit-in.github.io/bathinda-3d-terrain/
